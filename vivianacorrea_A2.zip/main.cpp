/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main() //sirve para la ejecucion del programa// 
{
    float valor1 =0; //son las variables//
    float valor2 =0;
    float resultadosuma =0;
    float resultadoresta =0;
    float resultadomult =0;
    float resultadodividir =0;
    
    cout<<"escribe el primer numero: "; //ayuda a mostrar en la pantalla un texto//
    cin>>valor1; //es la entrada de datos por medio del teclado//
    cout<<"escribe el segundo numero: ";
    cin>>valor2;
    
    resultadosuma = valor1 + valor2; //es la operacion de dos variables en este caso es la suma//
    resultadoresta = valor1 - valor2; //es la operacion de dos variables en este caso es la resta//
    resultadomult = valor1 * valor2; //es la operacion de dos variables en este caso es la multiplicacion//
    resultadodividir = valor1 / valor2; //es la operacion de dos variables en este caso es la division//
    
    cout<<"La suma es:"<< resultadosuma <<"\n";//nos mostrara el resultado obtenido de la operacion realizada//
    cout<<"La resta es:"<<resultadoresta<<"\n";
    cout<<"La multiplicacion es:"<<resultadomult<<"\n";
    cout<<"La division es:"<<resultadodividir<<"\n";

    return 0;
}